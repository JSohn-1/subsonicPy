# subsonicPy
Access to the subsonic API through Python 

Currently supports most api calls: \
ping \
createPlaylist \
addToPlaylist \
scan \
getScanStatus \
\
Self made ones:\
getId: gets song id\
getPId: gets playlist id 